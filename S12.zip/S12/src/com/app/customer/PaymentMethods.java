package com.app.customer;

public enum PaymentMethods {
    DEBITCARD, CREDITCARD, NETBANKING
}
