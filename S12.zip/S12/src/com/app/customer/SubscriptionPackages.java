package com.app.customer;

public enum SubscriptionPackages {
    BASIC, PREMIUM, VISIONARY;

   
    
}
